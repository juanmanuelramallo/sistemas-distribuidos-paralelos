#!/bin/bash

gcc-7 -fopenmp -o uno_openmp.o uno_openmp.c

echo " ================= 1 con openmp =================== "
for size in 256 512 1024
do
  echo " ==================================================== Matriz $((size)) "
  for thread in 1 2 4 8 d
  do
    echo " ---------------------------> Threads -> $thread"
    ./uno_openmp.o $size $thread
  done
done
